### Hexlet tests and linter status:
[![Actions Status](https://github.com/Sapphireisone/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Sapphireisone/python-project-50/actions)

Asciinema gendiff
https://asciinema.org/a/DvkhUZPU24KFOVRNVoxpj2vm8