### Hexlet tests and linter status:
[![Actions Status](https://github.com/Sapphireisone/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Sapphireisone/python-project-50/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/1f90af71fc8a8019f8c7/maintainability)](https://codeclimate.com/github/Sapphireisone/python-project-50/maintainability)

[![Test Coverage](https://api.codeclimate.com/v1/badges/1f90af71fc8a8019f8c7/test_coverage)](https://codeclimate.com/github/Sapphireisone/python-project-50/test_coverage)

Asciinema gendiff
https://asciinema.org/a/DvkhUZPU24KFOVRNVoxpj2vm8